package com.dtempire.digitalhub;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.net.Uri;import android.webkit.*;import android.view.*;

public class MainActivity extends Activity {
 WebView web;
 @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); setContentView(web); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); web.setBackgroundColor(Color.rgb(5,7,11)); web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,String url){ if(url.startsWith("http://")||url.startsWith("https://")||url.startsWith("mailto:")){startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));return true;}return false;}}); web.loadUrl("file:///android_asset/index.html"); }
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
