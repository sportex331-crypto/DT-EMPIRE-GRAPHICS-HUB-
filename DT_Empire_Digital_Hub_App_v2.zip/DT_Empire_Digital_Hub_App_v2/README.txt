DT EMPIRE DIGITAL HUB APP v2

This package contains:
1. www/index.html - the updated mobile web app with Store catalogue, iPhones, laptops, accessories, search/filter and WhatsApp availability buttons.
2. android/ - an Android Studio project that wraps the same app in a native Android WebView.

Pricing note: product figures in the demo are reference values and must be confirmed with a supplier before publishing as current prices. The app adds the configured DT Empire margin automatically.

Default margins:
- iPhones +N30,000
- Laptops +N10,000
- Monitors +N10,000
- Headsets +N5,000
- Chargers +N3,000
- Keyboard/Mouse +N3,000
- SSD/Flash accessories +N3,000
- Small accessories +N1,000
- Tablets/iPads +N10,000

The Android project can be opened in Android Studio and built into an APK. Google Play registration is not required for local APK testing.
